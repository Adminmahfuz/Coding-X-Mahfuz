# Music-Player with JavaScript

Function
1) Random Song
2) Previous Song
3) Next Song
4) Repeat Song
